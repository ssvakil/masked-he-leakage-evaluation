PLACE YOUR ProVerif MODEL HERE (rating.pv). It must be updated: the model
still encodes blind Schnorr, and the protocol now uses blind RSA with a
one-time key. See Section 5 of the paper.
