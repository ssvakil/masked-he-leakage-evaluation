import json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 9,
    "legend.fontsize": 7, "xtick.labelsize": 7, "ytick.labelsize": 7,
    "font.family": "serif", "mathtext.fontset": "dejavuserif",
    "figure.dpi": 300, "savefig.dpi": 600, "savefig.bbox": "tight",
    "figure.facecolor": "white", "axes.grid": True, "grid.alpha": .3,
    "grid.linewidth": .4, "axes.linewidth": .6, "lines.linewidth": 1.2,
    "lines.markersize": 4, "pdf.fonttype": 42, "ps.fonttype": 42,
})
def save(fig, name):
    """Vector PDF for the journal, 600-dpi RGB PNG as a fallback."""
    fig.savefig(name + ".pdf")
    fig.savefig(name + ".png", dpi=600, facecolor="white")
B=json.load(open("bench.json")); A=json.load(open("auth_sweep.json"))
d={b:[r for r in B if r["bits"]==b][0] for b in (2048,3072)}

# F1 operation cost breakdown
ops=[("encrypt","enc_ms"),("range proof\ngenerate","proof_gen_ms"),
     ("range proof\nverify","proof_ver_ms"),("partial\ndecrypt","partial_ms"),
     ("partial-dec\nproof","pdproof_ms"),("partial-dec\nverify","pdverify_ms"),
     ("blind-RSA\nsign","blindsign_ms"),("combine\nshares","combine_ms")]
x=np.arange(len(ops)); w=.38
fig,ax=plt.subplots(figsize=(6.6,3.3))
ax.bar(x-w/2,[d[2048][k] for _,k in ops],w,label="2048-bit",color="#1f77b4")
ax.bar(x+w/2,[d[3072][k] for _,k in ops],w,label="3072-bit",color="#ff7f0e")
ax.set_xticks(x); ax.set_xticklabels([n for n,_ in ops],fontsize=7)
ax.set_yscale("log"); ax.set_ylabel("time per operation (ms)")
ax.set_title("Cost of each protocol operation"); ax.legend(fontsize=8)
save(fig, "pfig1_ops")

# F2 server time vs users
fig,ax=plt.subplots(figsize=(5,3.2))
for b,c in ((2048,"#1f77b4"),(3072,"#ff7f0e")):
    rs=[r for r in B if r["bits"]==b]
    ax.plot([r["n_users"] for r in rs],[r["server_total_s"] for r in rs],
            marker="o",color=c,label=f"{b}-bit")
ax.set_xscale("log"); ax.set_yscale("log")
ax.set_xlabel("ratings submitted per aggregation round")
ax.set_ylabel("server-side time (s), single core")
ax.set_title("Aggregation round cost, one core"); ax.legend(fontsize=8)
save(fig, "pfig2_scaling")

# F3 where server time goes at n=10000
fig,axes=plt.subplots(1,2,figsize=(7.2,3.0))
for ax,b in zip(axes,(2048,3072)):
    r=[x for x in B if x["bits"]==b and x["n_users"]==10000][0]
    n=r["n_users"]; t=5
    parts={"range-proof\nverification":n*r["proof_ver_ms"],
           "homomorphic\naddition":n*r["add_ms"],
           "threshold\ndecryption":t*(r["partial_ms"]+r["pdproof_ms"]+r["pdverify_ms"])+r["combine_ms"]}
    tot=sum(parts.values())
    ax.bar(list(parts),[v/tot*100 for v in parts.values()],
           color=["#d62728","#2ca02c","#1f77b4"])
    for i,v in enumerate(parts.values()):
        ax.text(i,v/tot*100+1.5,f"{v/tot*100:.1f}%",ha="center",fontsize=8)
    ax.set_ylim(0,112); ax.set_title(f"{b}-bit, n=10 000"); ax.set_ylabel("% of round")
    ax.tick_params(axis='x',labelsize=7)
fig.suptitle("Where the aggregation round spends its time",y=1.03)
save(fig, "pfig3_breakdown")

# F4 authorities
au=[r for r in A if "n_auth" in r]
fig,ax=plt.subplots(figsize=(4.8,3.1))
ax.plot([r["n_auth"] for r in au],[r["decrypt_round_ms"] for r in au],
        marker="s",color="#9467bd",label="full round (partial + proof + verify)")
ax.plot([r["n_auth"] for r in au],[r["combine_ms"] for r in au],
        marker="o",color="#8c564b",label="Lagrange combine only")
ax.set_yscale("log"); ax.set_xlabel("number of authorities $n$ (with $t=\\lfloor (n-1)/2 \\rfloor$)")
ax.set_ylabel("time (ms)"); ax.set_title("Threshold decryption vs committee size")
ax.legend(fontsize=7); save(fig, "pfig4_authorities")
print("figures written")
for b in (2048,3072):
    r=[x for x in B if x["bits"]==b and x["n_users"]==10000][0]
    share=10000*r["proof_ver_ms"]/(r["server_total_s"]*1000)*100
    print(f"  {b}-bit: range-proof verification = {share:.1f}% of the round; "
          f"client {r['client_total_ms']:.1f} ms; throughput {1000/r['proof_ver_ms']:.1f} proofs/s/core")
