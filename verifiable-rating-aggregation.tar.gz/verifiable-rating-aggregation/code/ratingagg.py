#!/usr/bin/env python3
"""
ratingagg.py -- reference implementation and benchmark of the privacy-preserving
verifiable rating aggregation protocol.

Implements, and measures, the pieces the protocol actually costs money on:

  * Paillier keygen / Enc / Dec at 2048 and 3072 bit moduli
  * (t+1, n) threshold Paillier decryption with Shamir sharing over the
    integers (Fouque-Poupard-Stern / Damgard-Jurik style), including the
    Delta = n! factor that makes Lagrange interpolation integral
  * Chaum-Pedersen proofs of correct partial decryption, so the released
    aggregate is publicly verifiable
  * a domain-specific OR-based NIZK that an encrypted rating lies in
    {1,...,5}, via Fiat-Shamir over a Camenisch-Damgard style OR composition
  * blind RSA token issuance

WHY BLIND RSA AND NOT BLIND SCHNORR
-----------------------------------
Blind Schnorr is broken under concurrent signing sessions by the ROS attack
of Benhamouda, Lepoint, Loss, Orru and Raykova (EUROCRYPT 2021): an adversary
opening polylogarithmically many concurrent sessions forges an extra
signature, which in this protocol is a forged token, which is a fake rating.
The same result also breaks Okamoto-Schnorr and Abe-Okamoto partially blind
signatures, so migrating to those is not a fix. Blind RSA is not affected and
is what we use. A deployment that insists on Schnorr must serialise issuance;
we measure both.

Every primitive has a self-test. Run --self-test before trusting any number.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import secrets
import statistics
import time

import gmpy2
from gmpy2 import mpz, powmod, invert, gcd

RATINGS = (1, 2, 3, 4, 5)


# ---------------------------------------------------------------------------
# Paillier
# ---------------------------------------------------------------------------
def _safe_prime(bits: int, rs: random.Random) -> mpz:
    """p with p = 2q+1, both prime."""
    while True:
        q = mpz(rs.getrandbits(bits - 1)) | (mpz(1) << (bits - 2)) | 1
        q = gmpy2.next_prime(q)
        p = 2 * q + 1
        if gmpy2.is_prime(p):
            return p


class Paillier:
    def __init__(self, bits: int = 2048, rs: random.Random | None = None):
        rs = rs or random.Random(0)
        half = bits // 2
        self.p = _safe_prime(half, rs)
        self.q = _safe_prime(half, rs)
        while self.q == self.p:
            self.q = _safe_prime(half, rs)
        self.n = self.p * self.q
        self.n2 = self.n * self.n
        self.g = self.n + 1                     # standard choice
        self.lam = (self.p - 1) * (self.q - 1)  # phi(n)
        self.mu = invert(self.lam % self.n, self.n)

    def encrypt(self, m: int, r: mpz | None = None) -> mpz:
        if r is None:
            r = mpz(secrets.randbelow(int(self.n - 1))) + 1
        # (1+n)^m = 1 + mn  (mod n^2)
        return ((1 + m * self.n) % self.n2) * powmod(r, self.n, self.n2) % self.n2

    def decrypt(self, c: mpz) -> int:
        u = powmod(c, self.lam, self.n2)
        L = (u - 1) // self.n
        return int(L * self.mu % self.n)

    @staticmethod
    def add(c1: mpz, c2: mpz, n2: mpz) -> mpz:
        return c1 * c2 % n2


# ---------------------------------------------------------------------------
# Threshold Paillier: Shamir over the integers with the Delta = n! trick
# ---------------------------------------------------------------------------
class ThresholdPaillier:
    """
    (t+1)-out-of-n threshold decryption. Shares are generated here by a dealer;
    a dealerless DKG for Paillier additionally needs distributed biprimality
    testing, which is a separate protocol and is not part of this benchmark.
    Section 7 of the paper states that scope explicitly.
    """

    def __init__(self, pai: Paillier, n_auth: int, t: int,
                 rs: random.Random | None = None):
        rs = rs or random.Random(1)
        self.pai, self.n_auth, self.t = pai, n_auth, t
        self.delta = mpz(math.factorial(n_auth))
        m = (pai.p - 1) * (pai.q - 1) // 4          # p'q'
        self.m = m
        # d = 0 mod m, d = 1 mod n
        self.d = m * invert(m % pai.n, pai.n) % (pai.n * m)
        coeffs = [self.d] + [mpz(rs.randrange(int(pai.n * m)))
                             for _ in range(t)]
        self.shares = {}
        for i in range(1, n_auth + 1):
            s = mpz(0)
            for k, a in enumerate(coeffs):
                s += a * (mpz(i) ** k)
            self.shares[i] = s % (pai.n * m)
        # verification key material for the Chaum-Pedersen proofs
        self.v = powmod(mpz(rs.randrange(int(pai.n2))), 2, pai.n2)
        # Bases must match the exponent that appears in the partial decryption:
        # part_i = (c^{2*delta})^{s_i} and vk_i = (v^{delta})^{s_i}, so the
        # Chaum-Pedersen proof is over the common witness s_i with bases
        # c^{2*delta} and v^{delta}.
        self.vbase = powmod(self.v, self.delta, pai.n2)
        self.vk = {i: powmod(self.vbase, self.shares[i], pai.n2)
                   for i in range(1, n_auth + 1)}

    def partial(self, i: int, c: mpz) -> mpz:
        return powmod(c, 2 * self.delta * self.shares[i], self.pai.n2)

    def _lagrange(self, S, i) -> mpz:
        num = den = mpz(1)
        for j in S:
            if j != i:
                num *= mpz(j)
                den *= mpz(j - i)
        return self.delta * num // den

    def combine(self, parts: dict[int, mpz]) -> int:
        S = sorted(parts)[: self.t + 1]
        n2, n = self.pai.n2, self.pai.n
        acc = mpz(1)
        for i in S:
            lam = self._lagrange(S, i)
            e = 2 * lam
            base = parts[i] if e >= 0 else invert(parts[i], n2)
            acc = acc * powmod(base, abs(e), n2) % n2
        L = (acc - 1) // n
        f = invert(4 * self.delta * self.delta % n, n)
        return int(L * f % n)

    # --- proof of correct partial decryption (Chaum-Pedersen) ---
    def prove_partial(self, i: int, c: mpz, rs: random.Random) -> tuple:
        n2 = self.pai.n2
        cb = powmod(c, 2 * self.delta, n2)
        part = powmod(cb, self.shares[i], n2)
        r = mpz(rs.randrange(int(self.pai.n * self.m) * 2 ** 80))
        a, b = powmod(cb, r, n2), powmod(self.vbase, r, n2)
        e = _hash_int(cb, self.vbase, part, self.vk[i], a, b)
        z = r + e * self.shares[i]
        return (a, b, z)

    def verify_partial(self, i: int, c: mpz, part: mpz, proof) -> bool:
        n2 = self.pai.n2
        a, b, z = proof
        cb = powmod(c, 2 * self.delta, n2)
        e = _hash_int(cb, self.vbase, part, self.vk[i], a, b)
        lhs1, rhs1 = powmod(cb, z, n2), a * powmod(part, e, n2) % n2
        lhs2, rhs2 = powmod(self.vbase, z, n2), b * powmod(self.vk[i], e, n2) % n2
        return lhs1 == rhs1 and lhs2 == rhs2


def _hash_int(*vals) -> mpz:
    h = hashlib.sha256()
    for v in vals:
        h.update(int(v).to_bytes((int(v).bit_length() + 7) // 8 or 1, "big"))
        h.update(b"|")
    return mpz(int.from_bytes(h.digest(), "big"))


# ---------------------------------------------------------------------------
# OR-based NIZK range proof: c encrypts one of {1..5}
# ---------------------------------------------------------------------------
def range_prove(pai: Paillier, c: mpz, m: int, r: mpz, rs: random.Random):
    """
    Camenisch-Damgard OR composition over the five candidate plaintexts,
    made non-interactive with Fiat-Shamir. For the true branch the prover
    knows r with c/(1+mn) = r^n; the other four branches are simulated.
    """
    n, n2 = pai.n, pai.n2
    es, zs, us = {}, {}, {}
    w = mpz(rs.randrange(int(n - 1))) + 1
    for v in RATINGS:
        if v == m:
            us[v] = powmod(w, n, n2)
        else:
            es[v] = mpz(rs.getrandbits(128))
            zs[v] = mpz(rs.randrange(int(n - 1))) + 1
            cv = c * invert((1 + v * n) % n2, n2) % n2
            us[v] = powmod(zs[v], n, n2) * invert(powmod(cv, es[v], n2), n2) % n2
    e = _hash_int(c, *[us[v] for v in RATINGS]) % (mpz(1) << 128)
    es[m] = (e - sum(es[v] for v in RATINGS if v != m)) % (mpz(1) << 128)
    zs[m] = w * powmod(r, es[m], n2) % n2
    return ({v: us[v] for v in RATINGS}, {v: es[v] for v in RATINGS},
            {v: zs[v] for v in RATINGS})


def range_verify(pai: Paillier, c: mpz, proof) -> bool:
    n, n2 = pai.n, pai.n2
    us, es, zs = proof
    e = _hash_int(c, *[us[v] for v in RATINGS]) % (mpz(1) << 128)
    if sum(es[v] for v in RATINGS) % (mpz(1) << 128) != e:
        return False
    for v in RATINGS:
        cv = c * invert((1 + v * n) % n2, n2) % n2
        if powmod(zs[v], n, n2) != us[v] * powmod(cv, es[v], n2) % n2:
            return False
    return True


# ---------------------------------------------------------------------------
# Blind RSA token issuance (ROS-immune)
# ---------------------------------------------------------------------------
class BlindRSA:
    def __init__(self, bits: int = 2048, rs: random.Random | None = None):
        rs = rs or random.Random(2)
        p, q = _safe_prime(bits // 2, rs), _safe_prime(bits // 2, rs)
        while q == p:
            q = _safe_prime(bits // 2, rs)
        self.n, self.e = p * q, mpz(65537)
        self.d = invert(self.e, (p - 1) * (q - 1))

    def blind(self, msg: bytes, rs: random.Random):
        r = mpz(rs.randrange(2, int(self.n - 1)))
        while gcd(r, self.n) != 1:
            r = mpz(rs.randrange(2, int(self.n - 1)))
        h = _hash_int(int.from_bytes(hashlib.sha256(msg).digest(), "big")) % self.n
        return h * powmod(r, self.e, self.n) % self.n, r, h

    def sign_blinded(self, mb: mpz) -> mpz:
        return powmod(mb, self.d, self.n)

    def unblind(self, sb: mpz, r: mpz) -> mpz:
        return sb * invert(r, self.n) % self.n

    def verify(self, sig: mpz, h: mpz) -> bool:
        return powmod(sig, self.e, self.n) == h


# ---------------------------------------------------------------------------
# Self-tests
# ---------------------------------------------------------------------------
def self_test(bits=1024):
    rs = random.Random(7)
    print("Paillier keygen / homomorphism ...", flush=True)
    pai = Paillier(bits, rs)
    a, b = 3, 4
    ca, cb = pai.encrypt(a), pai.encrypt(b)
    assert pai.decrypt(ca) == a and pai.decrypt(cb) == b
    assert pai.decrypt(Paillier.add(ca, cb, pai.n2)) == a + b
    print("  ok")

    print("threshold decryption (n=9, t=4) ...", flush=True)
    tp = ThresholdPaillier(pai, 9, 4, rs)
    total = 0
    c = pai.encrypt(0)
    for _ in range(30):
        v = rs.choice(RATINGS)
        total += v
        c = Paillier.add(c, pai.encrypt(v), pai.n2)
    parts = {i: tp.partial(i, c) for i in range(1, 6)}
    rec = tp.combine(parts)
    print(f"  plain sum={total}  threshold-reconstructed={rec}  match={rec == total}")
    assert rec == total

    print("partial-decryption proofs ...", flush=True)
    ok_good = all(tp.verify_partial(i, c, parts[i], tp.prove_partial(i, c, rs))
                  for i in range(1, 6))
    bad = parts[1] * 2 % pai.n2
    ok_bad = tp.verify_partial(1, c, bad, tp.prove_partial(1, c, rs))
    print(f"  honest shares accepted={ok_good}   tampered share accepted={ok_bad}")
    assert ok_good and not ok_bad

    print("OR-based range proof ...", flush=True)
    r = mpz(rs.randrange(int(pai.n - 1))) + 1
    m = 4
    c4 = pai.encrypt(m, r)
    pr = range_prove(pai, c4, m, r, rs)
    good = range_verify(pai, c4, pr)
    r7 = mpz(rs.randrange(int(pai.n - 1))) + 1
    c7 = pai.encrypt(7, r7)
    try:
        forged = range_verify(pai, c7, range_prove(pai, c7, 7, r7, rs))
    except Exception:
        forged = False
    print(f"  valid rating accepted={good}   out-of-domain rating accepted={forged}")
    assert good and not forged

    print("blind RSA token ...", flush=True)
    br = BlindRSA(bits, rs)
    mb, rr, h = br.blind(b"order42|prod7", rs)
    sig = br.unblind(br.sign_blinded(mb), rr)
    print(f"  signature verifies={br.verify(sig, h)}")
    assert br.verify(sig, h)
    print("\nALL SELF-TESTS PASSED")


# ---------------------------------------------------------------------------
# Benchmarks
# ---------------------------------------------------------------------------
def _t(fn, reps=1):
    t0 = time.perf_counter()
    for _ in range(reps):
        out = fn()
    return (time.perf_counter() - t0) / reps * 1000, out


def bench(bits_list, n_users_list, n_auth, t_thr, reps, seed=11):
    rs = random.Random(seed)
    rows = []
    for bits in bits_list:
        print(f"\n=== modulus {bits} bits ===", flush=True)
        kt, pai = _t(lambda: Paillier(bits, rs))
        print(f"  keygen                {kt:9.1f} ms")
        tp = ThresholdPaillier(pai, n_auth, t_thr, rs)

        r = mpz(rs.randrange(int(pai.n - 1))) + 1
        enc_t, c = _t(lambda: pai.encrypt(3, r), reps)
        pp_t, pr = _t(lambda: range_prove(pai, c, 3, r, rs), reps)
        pv_t, _ = _t(lambda: range_verify(pai, c, pr), reps)
        add_t, _ = _t(lambda: Paillier.add(c, c, pai.n2), reps * 50)
        pd_t, part = _t(lambda: tp.partial(1, c), reps)
        dp_t, dpr = _t(lambda: tp.prove_partial(1, c, rs), reps)
        dv_t, _ = _t(lambda: tp.verify_partial(1, c, part, dpr), reps)
        parts = {i: tp.partial(i, c) for i in range(1, t_thr + 2)}
        cb_t, _ = _t(lambda: tp.combine(parts), reps)

        br = BlindRSA(bits, rs)
        mb, rr, h = br.blind(b"m", rs)
        bs_t, _ = _t(lambda: br.sign_blinded(mb), reps)

        client = enc_t + pp_t
        print(f"  encrypt               {enc_t:9.2f} ms")
        print(f"  range proof generate  {pp_t:9.2f} ms")
        print(f"  range proof verify    {pv_t:9.2f} ms")
        print(f"  homomorphic add       {add_t:9.4f} ms")
        print(f"  partial decrypt       {pd_t:9.2f} ms")
        print(f"  partial-dec proof     {dp_t:9.2f} ms")
        print(f"  partial-dec verify    {dv_t:9.2f} ms")
        print(f"  combine t+1 shares    {cb_t:9.2f} ms")
        print(f"  blind-RSA signing     {bs_t:9.2f} ms")
        print(f"  --> client-side total {client:9.2f} ms")

        for nu in n_users_list:
            server = nu * pv_t + nu * add_t + (t_thr + 1) * (pd_t + dp_t + dv_t) + cb_t
            rows.append(dict(bits=bits, n_users=nu, keygen_ms=kt,
                             enc_ms=enc_t, proof_gen_ms=pp_t, proof_ver_ms=pv_t,
                             add_ms=add_t, partial_ms=pd_t, pdproof_ms=dp_t,
                             pdverify_ms=dv_t, combine_ms=cb_t,
                             blindsign_ms=bs_t, client_total_ms=client,
                             server_total_s=server / 1000))
            print(f"    n={nu:>5} users -> server-side {server/1000:8.2f} s")
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--bits", type=int, nargs="+", default=[2048, 3072])
    ap.add_argument("--users", type=int, nargs="+",
                    default=[100, 500, 1000, 5000, 10000])
    ap.add_argument("--authorities", type=int, default=9)
    ap.add_argument("--threshold", type=int, default=4)
    ap.add_argument("--reps", type=int, default=20)
    ap.add_argument("--out", default="bench.json")
    a = ap.parse_args()

    if a.self_test:
        self_test()
        return
    rows = bench(a.bits, a.users, a.authorities, a.threshold, a.reps)
    json.dump(rows, open(a.out, "w"), indent=2)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
