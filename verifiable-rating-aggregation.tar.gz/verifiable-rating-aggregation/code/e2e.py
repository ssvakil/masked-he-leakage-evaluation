"""End-to-end aggregation round, actually executed rather than composed from
micro-benchmarks. Measures wall-clock for: n clients producing an encrypted
rating plus range proof, the server verifying every proof and folding every
ciphertext, and a full threshold decryption with proofs. Also records the
machine it ran on."""
import json, platform, random, time, subprocess
import ratingagg as R

def cpu():
    try:
        for l in open("/proc/cpuinfo"):
            if l.startswith("model name"): return l.split(":",1)[1].strip()
    except Exception: pass
    return platform.processor() or "unknown"

def mem_gb():
    try:
        for l in open("/proc/meminfo"):
            if l.startswith("MemTotal"): return round(int(l.split()[1])/1048576,1)
    except Exception: return None

def run(n_users, bits=2048, n_auth=9, t=4, seed=99):
    rs = random.Random(seed)
    pai = R.Paillier(bits, rs)
    tp  = R.ThresholdPaillier(pai, n_auth, t, rs)

    # --- clients ---
    t0=time.perf_counter(); subs=[]; truth=0
    for _ in range(n_users):
        m = rs.choice(R.RATINGS); truth += m
        r = R.mpz(rs.randrange(int(pai.n-1)))+1
        c = pai.encrypt(m, r)
        subs.append((c, R.range_prove(pai, c, m, r, rs)))
    t_client=time.perf_counter()-t0

    # --- server: verify every proof, fold every ciphertext ---
    t0=time.perf_counter(); acc=pai.encrypt(0); bad=0
    for c,pr in subs:
        if not R.range_verify(pai, c, pr): bad+=1; continue
        acc = R.Paillier.add(acc, c, pai.n2)
    t_server=time.perf_counter()-t0

    # --- threshold decryption with proofs, verified ---
    t0=time.perf_counter()
    parts={i: tp.partial(i, acc) for i in range(1, t+2)}
    prfs ={i: tp.prove_partial(i, acc, rs) for i in parts}
    okp  = all(tp.verify_partial(i, acc, parts[i], prfs[i]) for i in parts)
    total= tp.combine(parts)
    t_dec=time.perf_counter()-t0

    return dict(n_users=n_users, bits=bits, rejected=bad, proofs_ok=okp,
                recovered=total, expected=truth, correct=(total==truth),
                client_s=t_client, server_s=t_server, decrypt_s=t_dec,
                total_s=t_client+t_server+t_dec)

if __name__ == "__main__":
    env = dict(cpu=cpu(), cores=len(__import__("os").sched_getaffinity(0)),
               mem_gb=mem_gb(), python=platform.python_version(),
               gmpy2=R.gmpy2.version(), platform=platform.platform())
    print("environment:", json.dumps(env, indent=2), flush=True)
    out=[]
    for n in (100, 250, 500):
        r = run(n); out.append(r)
        print(f"n={n:>4}  client {r['client_s']:7.2f}s  server {r['server_s']:7.2f}s  "
              f"decrypt {r['decrypt_s']:5.2f}s  total {r['total_s']:7.2f}s  "
              f"sum correct={r['correct']}  proofs ok={r['proofs_ok']}", flush=True)
    json.dump(dict(env=env, runs=out), open("e2e.json","w"), indent=2)
