import time, random, json
from concurrent.futures import ProcessPoolExecutor
import ratingagg as R
rs=random.Random(31); pai=R.Paillier(2048,rs)
r=R.mpz(rs.randrange(int(pai.n-1)))+1; c=pai.encrypt(3,r); pr=R.range_prove(pai,c,3,r,rs)
G={}
def init(): pass
def work(_):
    return R.range_verify(pai,c,pr)
if __name__=="__main__":
    N=48
    t0=time.perf_counter()
    for _ in range(N): R.range_verify(pai,c,pr)
    seq=time.perf_counter()-t0
    print(f"sequential {N} verifications: {seq:.2f}s  ({seq/N*1000:.1f} ms each)")
    out=[dict(workers=1, sec=seq, speedup=1.0, per_ms=seq/N*1000)]
    for w in (2,4):
        t0=time.perf_counter()
        with ProcessPoolExecutor(max_workers=w) as ex: list(ex.map(work, range(N)))
        p=time.perf_counter()-t0
        print(f"{w} processes: {p:.2f}s  speedup {seq/p:.2f}x  throughput {N/p:.1f} proofs/s")
        out.append(dict(workers=w, sec=p, speedup=seq/p, per_ms=p/N*1000))
    json.dump(out, open("par.json","w"), indent=2)
