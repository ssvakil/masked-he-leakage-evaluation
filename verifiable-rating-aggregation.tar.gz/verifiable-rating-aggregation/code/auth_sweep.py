"""Threshold-decryption cost as the authority count grows, and the parallel
speedup available on the range-proof verification bottleneck."""
import json, random, time, statistics
from concurrent.futures import ThreadPoolExecutor
import ratingagg as R

rs = random.Random(21)
pai = R.Paillier(2048, rs)
c = pai.encrypt(3)
rows = []
for n_auth in (3, 5, 9, 15, 21):
    t_thr = (n_auth - 1) // 2
    tp = R.ThresholdPaillier(pai, n_auth, t_thr, rs)
    t0 = time.perf_counter()
    parts = {i: tp.partial(i, c) for i in range(1, t_thr + 2)}
    prf = {i: tp.prove_partial(i, c, rs) for i in parts}
    ok = all(tp.verify_partial(i, c, parts[i], prf[i]) for i in parts)
    tot = (time.perf_counter() - t0) * 1000
    t1 = time.perf_counter(); tp.combine(parts); comb = (time.perf_counter() - t1) * 1000
    rows.append(dict(n_auth=n_auth, t=t_thr, shares_used=t_thr + 1,
                     decrypt_round_ms=tot, combine_ms=comb, verified=ok))
    print(f"n={n_auth:>3} t={t_thr:>2}  decryption round {tot:8.1f} ms  "
          f"combine {comb:6.2f} ms  proofs ok={ok}", flush=True)

# parallel speedup on the verification bottleneck
r = R.mpz(rs.randrange(int(pai.n - 1))) + 1
cc = pai.encrypt(3, r); pr = R.range_prove(pai, cc, 3, r, rs)
N = 64
t0 = time.perf_counter()
for _ in range(N): R.range_verify(pai, cc, pr)
seq = time.perf_counter() - t0
for w in (2, 4):
    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=w) as ex:
        list(ex.map(lambda _: R.range_verify(pai, cc, pr), range(N)))
    par = time.perf_counter() - t0
    print(f"verification x{N}: sequential {seq:.2f}s  {w} workers {par:.2f}s  "
          f"speedup {seq/par:.2f}x", flush=True)
    rows.append(dict(workers=w, seq_s=seq, par_s=par, speedup=seq/par))
json.dump(rows, open("auth_sweep.json","w"), indent=2)
