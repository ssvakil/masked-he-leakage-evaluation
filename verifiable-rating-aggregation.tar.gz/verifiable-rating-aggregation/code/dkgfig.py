import json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 9,
    "legend.fontsize": 7, "xtick.labelsize": 7, "ytick.labelsize": 7,
    "font.family": "serif", "mathtext.fontset": "dejavuserif",
    "figure.dpi": 300, "savefig.dpi": 600, "savefig.bbox": "tight",
    "figure.facecolor": "white", "axes.grid": True, "grid.alpha": .3,
    "grid.linewidth": .4, "axes.linewidth": .6, "lines.linewidth": 1.2,
    "lines.markersize": 4, "pdf.fonttype": 42, "ps.fonttype": 42,
})
def save(fig, name):
    """Vector PDF for the journal, 600-dpi RGB PNG as a fallback."""
    fig.savefig(name + ".pdf")
    fig.savefig(name + ".png", dpi=600, facecolor="white")
S=json.load(open("dkg_small.json")); L=json.load(open("dkg_512.json"))
fig,axes=plt.subplots(1,2,figsize=(8.2,3.2))

ax=axes[0]
for pb,c,mk in ((128,"#1f77b4","o"),(256,"#ff7f0e","s")):
    rs=[r for r in S if r["prime_bits"]==pb]
    ax.plot([r["parties"] for r in rs],[r["ms_per_candidate"] for r in rs],
            marker=mk,color=c,label=f"{pb}-bit primes, 1024-bit helper")
rs=[r for r in L if r["prime_bits"]==512]
ax.plot([r["parties"] for r in rs],[r["ms_per_candidate"] for r in rs],
        marker="^",color="#d62728",label="512-bit primes, 2048-bit helper")
n=np.array([3,5,9]); ref=25.4*(n*(n-1))/6
ax.plot(n,ref,"k--",lw=1,label=r"$\propto n(n-1)$")
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xticks([3,5,9]); ax.set_xticklabels([3,5,9])
ax.set_xlabel("number of parties $n$"); ax.set_ylabel("ms per candidate")
ax.set_title("DKG candidate cost is quadratic in $n$"); ax.legend(fontsize=6.5)

ax=axes[1]
labels=["aggregation round\n(10 000 ratings)","threshold decryption\n(one round)","DKG setup\n(9 parties, 2048-bit)"]
vals=[537.6, 0.60, 265.6*3600]
ax.bar(labels,vals,color=["#d62728","#2ca02c","#9467bd"])
for i,v in enumerate(vals):
    lab = f"{v:.2f} s" if v<3600 else f"{v/3600:,.0f} core-h"
    ax.text(i,v*1.6,lab,ha="center",fontsize=8)
ax.set_yscale("log"); ax.set_ylabel("seconds (log)"); ax.set_ylim(0.1,1e7)
ax.tick_params(axis='x',labelsize=7)
ax.set_title("One-time setup against recurring cost")
save(fig, "pfig5_dkg"); print("wrote pfig5_dkg.png")
