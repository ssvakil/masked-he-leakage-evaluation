#!/usr/bin/env python3
"""
dkg.py -- dealerless distributed key generation for threshold Paillier,
following Boneh and Franklin, with the cost actually measured.

WHAT IS IMPLEMENTED
-------------------
  * additive sharing of the candidate primes across n parties, with the
    residue conditions p = q = 3 (mod 4) that the biprimality test needs
  * distributed computation of N = p*q from the shares, using Paillier-based
    two-party multiplication for every cross term p_i * q_j: party i sends
    Enc_i(p_i), party j returns Enc_i(p_i*q_j - r_ji) homomorphically, party i
    decrypts. Neither party learns the other's share. This is n(n-1) two-party
    multiplications per candidate.
  * distributed trial division, which rejects most candidates cheaply
  * the Boneh-Franklin distributed biprimality test: party 1 computes
    g^((N-p_1-q_1+1)/4) and the others g^((p_i+q_i)/4), and the product is
    checked against +-1 mod N. No party learns p or q.

WHAT IS NOT
-----------
  * the robustness layer. A malicious party can make the protocol output a
    non-RSA modulus; detecting that needs zero-knowledge proofs of correct
    behaviour on each share, which we do not implement. The measurement is
    therefore a semi-honest cost, and the paper says so.
  * conversion of the resulting factorisation shares into threshold decryption
    key shares. That step is share-local arithmetic and is cheap relative to
    finding the modulus; it is not on the critical path measured here.

The headline result is that DKG dominates every other cost in the protocol by
orders of magnitude, which is worth reporting precisely because the protocol's
title advertises it.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import time

import gmpy2
from gmpy2 import mpz, powmod, invert, gcd

import ratingagg as RA

SMALL_PRIMES = [int(p) for p in gmpy2.mpz(2).__class__ and []] or None
def _small_primes(bound: int):
    sieve = bytearray([1]) * bound
    sieve[0:2] = b"\x00\x00"
    for i in range(2, int(bound ** 0.5) + 1):
        if sieve[i]:
            sieve[i * i::i] = bytearray(len(sieve[i * i::i]))
    return [i for i in range(bound) if sieve[i]]


# ---------------------------------------------------------------------------
# Two-party multiplication of additive shares, using Paillier
# ---------------------------------------------------------------------------
class MulParty:
    """Holds a Paillier key used only as a multiplication helper."""

    def __init__(self, bits: int, rs: random.Random):
        self.pai = RA.Paillier(bits, rs)


SEC_KAPPA = 80


def two_party_mul(owner: MulParty, a: mpz, b: mpz, rs: random.Random,
                  bound_bits: int):
    """
    Party A holds a, party B holds b. Returns (sa, sb) with sa + sb = a*b
    EXACTLY over the integers, where A learns only sa and B only sb.

    A sends Enc(a); B computes Enc(a)^b * Enc(-r) and returns it; A decrypts.
    The blinding r is drawn from [0, 2^(bound_bits+kappa)) rather than from
    [0, n): drawing it from the full residue class makes a*b - r wrap, and the
    two shares then reconstruct only modulo n, not over the integers, which is
    what a first version of this file got wrong. With |a*b - r| < n/2 the
    decryption is lifted to its signed representative and reconstruction is
    exact. The statistical distance from uniform is 2^-kappa.
    """
    pai = owner.pai
    assert pai.n.bit_length() > bound_bits + SEC_KAPPA + 2, \
        "helper modulus too small for exact integer reconstruction"
    ca = pai.encrypt(int(a))
    r = mpz(rs.getrandbits(bound_bits + SEC_KAPPA))
    cb = powmod(ca, int(b), pai.n2) * pai.encrypt(int((-r) % pai.n)) % pai.n2
    sa = mpz(pai.decrypt(cb))
    if sa > pai.n // 2:          # lift to the signed representative
        sa -= pai.n
    return sa, r


# ---------------------------------------------------------------------------
# Candidate generation and the distributed pipeline
# ---------------------------------------------------------------------------
def sample_shares(n_parties: int, bits: int, rs: random.Random):
    """p = sum p_i with p = 3 (mod 4): party 1 takes 3 mod 4, others 0 mod 4."""
    out = []
    for i in range(n_parties):
        v = mpz(rs.getrandbits(bits)) | (mpz(1) << (bits - 1))
        v = v - (v % 4) + (3 if i == 0 else 0)
        out.append(v)
    return out


def distributed_product(pshares, qshares, helpers, rs):
    """N = (sum p_i)(sum q_j) via local squares plus n(n-1) two-party mults."""
    n = len(pshares)
    bound = max(x.bit_length() for x in pshares) + \
            max(x.bit_length() for x in qshares) + 2
    total = mpz(0)
    n_mults = 0
    for i in range(n):
        total += pshares[i] * qshares[i]
        for j in range(n):
            if i == j:
                continue
            sa, sb = two_party_mul(helpers[i], pshares[i], qshares[j], rs,
                                   bound)
            total += sa + sb
            n_mults += 1
    return total, n_mults


def trial_division(N: mpz, primes) -> bool:
    for p in primes:
        if N % p == 0:
            return False
    return True


def biprimality(N: mpz, pshares, qshares, rs: random.Random) -> bool:
    """Boneh-Franklin test with a single random base."""
    for _ in range(8):
        g = mpz(rs.randrange(2, int(N) - 1))
        if gcd(g, N) != 1:
            return False
        if gmpy2.jacobi(g, N) == 1:
            break
    else:
        return False
    n = len(pshares)
    e1 = (N - pshares[0] - qshares[0] + 1) // 4
    v = powmod(g, e1, N)
    for i in range(1, n):
        e = (pshares[i] + qshares[i]) // 4
        v = v * invert(powmod(g, e, N), N) % N
    return v == 1 or v == N - 1


# ---------------------------------------------------------------------------
def dkg_round(n_parties, prime_bits, helpers, primes, rs, budget=None):
    """Run candidates until one passes, or until `budget` candidates are tried."""
    stats = dict(candidates=0, passed_trial=0, mults=0,
                 t_product=0.0, t_trial=0.0, t_biprime=0.0, found=False)
    while budget is None or stats["candidates"] < budget:
        stats["candidates"] += 1
        ps = sample_shares(n_parties, prime_bits, rs)
        qs = sample_shares(n_parties, prime_bits, rs)

        t0 = time.perf_counter()
        N, nm = distributed_product(ps, qs, helpers, rs)
        stats["t_product"] += time.perf_counter() - t0
        stats["mults"] += nm

        t0 = time.perf_counter()
        ok = trial_division(N, primes)
        stats["t_trial"] += time.perf_counter() - t0
        if not ok:
            continue
        stats["passed_trial"] += 1

        t0 = time.perf_counter()
        good = biprimality(N, ps, qs, rs)
        stats["t_biprime"] += time.perf_counter() - t0
        if good:
            stats["found"] = True
            stats["N"] = int(N)
            p, q = sum(ps), sum(qs)
            stats["truly_biprime"] = bool(gmpy2.is_prime(p) and gmpy2.is_prime(q))
            return stats
    return stats


def self_test():
    rs = random.Random(5)
    print("two-party multiplication ...", flush=True)
    h = MulParty(512, rs)
    a, b = mpz(123456789), mpz(987654321)
    sa, sb = two_party_mul(h, a, b, rs, a.bit_length() + b.bit_length() + 2)
    print(f"  shares reconstruct product: {sa + sb == a * b}")
    assert sa + sb == a * b

    print("distributed product across 3 parties ...", flush=True)
    helpers = [MulParty(1024, rs) for _ in range(3)]
    ps, qs = sample_shares(3, 64, rs), sample_shares(3, 64, rs)
    N, nm = distributed_product(ps, qs, helpers, rs)
    print(f"  N == (sum p)(sum q): {N == sum(ps) * sum(qs)}   "
          f"two-party mults used: {nm}")
    assert N == sum(ps) * sum(qs)

    print("residue conditions ...", flush=True)
    print(f"  sum(p) mod 4 = {sum(ps) % 4}   sum(q) mod 4 = {sum(qs) % 4}")
    assert sum(ps) % 4 == 3 and sum(qs) % 4 == 3

    print("biprimality test on a known biprime and a known non-biprime ...",
          flush=True)
    # build a genuine biprime with the right residues, shared additively
    while True:
        p = gmpy2.next_prime(mpz(rs.getrandbits(64)))
        if p % 4 == 3:
            break
    while True:
        q = gmpy2.next_prime(mpz(rs.getrandbits(64)))
        if q % 4 == 3 and q != p:
            break
    ps2 = [p - 8, mpz(4), mpz(4)]
    qs2 = [q - 8, mpz(4), mpz(4)]
    good = biprimality(p * q, ps2, qs2, rs)
    bad_p = p * 4 + 3
    bad = biprimality(bad_p * q, [bad_p - 8, mpz(4), mpz(4)], qs2, rs)
    print(f"  genuine biprime accepted: {good}    composite-factor case accepted: {bad}")
    assert good
    print("\nALL DKG SELF-TESTS PASSED")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--parties", type=int, nargs="+", default=[3, 5, 9])
    ap.add_argument("--prime-bits", type=int, nargs="+", default=[128, 256, 512])
    ap.add_argument("--budget", type=int, default=60,
                    help="candidates per configuration (cost measurement)")
    ap.add_argument("--helper-bits", type=int, default=1024)
    ap.add_argument("--out", default="dkg_bench.json")
    a = ap.parse_args()

    if a.self_test:
        self_test()
        return

    primes = _small_primes(10000)[1:]
    rs = random.Random(17)
    rows = []
    for nb in a.prime_bits:
        for np_ in a.parties:
            helpers = [MulParty(a.helper_bits, rs) for _ in range(np_)]
            st = dkg_round(np_, nb, helpers, primes, rs, budget=a.budget)
            c = st["candidates"]
            per_cand = (st["t_product"] + st["t_trial"] + st["t_biprime"]) / c
            row = dict(parties=np_, prime_bits=nb, modulus_bits=2 * nb,
                       candidates=c, passed_trial=st["passed_trial"],
                       trial_pass_rate=st["passed_trial"] / c,
                       mults_per_candidate=st["mults"] / c,
                       ms_product=st["t_product"] / c * 1000,
                       ms_trial=st["t_trial"] / c * 1000,
                       ms_biprime=(st["t_biprime"] / st["passed_trial"] * 1000)
                                  if st["passed_trial"] else 0.0,
                       ms_per_candidate=per_cand * 1000,
                       found=st["found"])
            rows.append(row)
            print(f"parties={np_:>2} prime={nb:>4}b (modulus {2*nb}b): "
                  f"{row['ms_per_candidate']:9.1f} ms/candidate  "
                  f"product {row['ms_product']:8.1f}  trial {row['ms_trial']:6.2f}  "
                  f"biprime {row['ms_biprime']:7.1f}  "
                  f"trial-pass {row['trial_pass_rate']:.2f}  "
                  f"mults/cand {row['mults_per_candidate']:.0f}", flush=True)
    json.dump(rows, open(a.out, "w"), indent=2)
    print(f"\nwrote {a.out}")


if __name__ == "__main__":
    main()
