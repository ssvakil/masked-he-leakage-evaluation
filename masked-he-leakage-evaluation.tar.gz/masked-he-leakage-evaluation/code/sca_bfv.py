#!/usr/bin/env python3
"""
sca_bfv.py -- Leakage evaluation of masked / shuffled BFV polynomial arithmetic.

Replaces the AES-S-box-based simulation with an attack on the *actual*
RLWE intermediate that BFV decryption computes.

Target of attack
----------------
BFV decryption evaluates  c0 + c1 * s  in R_q = Z_q[X]/(X^N + 1).
With NTT-based multiplication this is a coefficient-wise product

        z_k = chat1[k] * shat[k]   (mod q),   k = 0 .. N-1

where chat1 = NTT(c1) is *public* (the attacker sees the ciphertext) and
shat = NTT(s) is secret.  Recovering shat[k] for all k and applying the
inverse NTT yields the secret key.  This is the intermediate targeted by
Primas-Pessl-Mangard (CHES 2017) and RevEAL (DATE 2022).

Leakage model
-------------
        L = HW(z) + Normal(0, sigma^2)

stated explicitly so the evaluation is falsifiable.  HW is the Hamming
weight of the canonical representative in [0, q).

Countermeasures
---------------
  * Arithmetic masking mod q with d shares:
        shat[k] = sum_i shat_i[k]  (mod q),  shares refreshed every execution.
    Every share leaks -- unlike the original notebook, which leaked only
    one share and therefore made masking look unbreakable by construction.
  * Shuffling: the N coefficient-wise products are executed in a random
    order, so the target coefficient lands in a random time slot.

Attacks
-------
  * d-th order CPA.  The d share sub-samples of a slot are centred and
    multiplied.  The predictor is the d-fold cyclic autoconvolution of HW,
        h_d(v) = (HW * HW * ... * HW)(v) / q^(d-1),
    which is the exact expectation E[ prod_i HW(z_i) | sum_i z_i = v ].
    Computed via FFT.
  * Non-specific fixed-vs-random TVLA, first order and d-th order.

Everything is repeated over several seeds and reported as mean +/- std.

Author: (fill in)
License: MIT
"""

from __future__ import annotations

import argparse
import json
import os
import time
from dataclasses import dataclass, asdict

import numpy as np
import pandas as pd

# --------------------------------------------------------------------------
# Parameter sets
# --------------------------------------------------------------------------

# Leakage instance.  Small q so the CPA hypothesis space Z_q is enumerable;
# this is standard practice in the SCA literature and does not change the
# structure of the attacked operation.  Requires 2N | q-1 for a negacyclic NTT.
LEAK_N = 128
LEAK_Q = 3329          # 3328 = 13 * 256 = 13 * 2N   -> negacyclic NTT exists

# Correctness instance.  Realistic-ish BFV parameters; schoolbook
# multiplication in int64, no NTT needed.
CORR_N = 256
CORR_Q = 1073750017    # prime, 512 | q-1, < 2^31
CORR_T = 1024          # plaintext modulus
CORR_SIGMA = 3.2


# --------------------------------------------------------------------------
# Negacyclic NTT
# --------------------------------------------------------------------------

def _is_prime(n: int) -> bool:
    if n < 2:
        return False
    for p in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % p == 0:
            return n == p
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for a in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(r - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


def _primitive_root(q: int) -> int:
    factors = set()
    m, d = q - 1, 2
    while d * d <= m:
        while m % d == 0:
            factors.add(d)
            m //= d
        d += 1
    if m > 1:
        factors.add(m)
    for g in range(2, q):
        if all(pow(g, (q - 1) // f, q) != 1 for f in factors):
            return g
    raise RuntimeError("no primitive root")


class NegacyclicNTT:
    """
    Iterative negacyclic NTT for Z_q[X]/(X^N + 1), Cooley-Tukey butterflies
    with bit-reversed twiddle table (the standard Kyber/NewHope layout).
    Forward output is in bit-reversed order; pointwise products are still
    correct, which is all the attack needs.
    """

    def __init__(self, n: int, q: int):
        if n & (n - 1):
            raise ValueError("N must be a power of two")
        if (q - 1) % (2 * n):
            raise ValueError(f"need 2N | q-1 (N={n}, q={q})")
        self.n, self.q = n, q
        g = _primitive_root(q)
        psi = pow(g, (q - 1) // (2 * n), q)          # primitive 2N-th root
        logn = n.bit_length() - 1
        brv = [int(format(i, f"0{logn}b")[::-1], 2) for i in range(n)]
        zetas = [pow(psi, brv[i], q) for i in range(n)]

        # Pre-compute the exact butterfly schedule so forward/inverse match.
        self.plan = []
        k, length = 1, n >> 1
        while length >= 1:
            for start in range(0, n, length << 1):
                self.plan.append((start, length, zetas[k]))
                k += 1
            length >>= 1
        self.n_inv = pow(n, q - 2, q)

    def forward(self, a: np.ndarray) -> np.ndarray:
        q = self.q
        x = a.astype(np.int64).copy()
        for start, length, z in self.plan:
            lo = slice(start, start + length)
            hi = slice(start + length, start + 2 * length)
            t = (x[..., hi] * z) % q
            u = x[..., lo]
            x[..., hi] = (u - t) % q
            x[..., lo] = (u + t) % q
        return x

    def inverse(self, a: np.ndarray) -> np.ndarray:
        q = self.q
        x = a.astype(np.int64).copy()
        for start, length, z in reversed(self.plan):
            zi = pow(int(z), q - 2, q)
            lo = slice(start, start + length)
            hi = slice(start + length, start + 2 * length)
            u = x[..., lo].copy()
            v = x[..., hi]
            x[..., lo] = (u + v) % q
            x[..., hi] = ((u - v) * zi) % q
        return (x * self.n_inv) % q


def schoolbook_negacyclic(a: np.ndarray, b: np.ndarray, q: int) -> np.ndarray:
    n = len(a)
    out = np.zeros(n, dtype=np.int64)
    for i in range(n):
        for j in range(n):
            k = i + j
            v = int(a[i]) * int(b[j])
            if k < n:
                out[k] = (out[k] + v) % q
            else:
                out[k - n] = (out[k - n] - v) % q
    return out % q


# --------------------------------------------------------------------------
# Leakage helpers
# --------------------------------------------------------------------------

def hamming_weight_table(q: int) -> np.ndarray:
    """HW of the canonical representative, for every element of Z_q."""
    v = np.arange(q, dtype=np.uint32)
    hw = np.zeros(q, dtype=np.float64)
    for bit in range(32):
        hw += (v >> bit) & 1
    return hw


def order_d_predictor(hw: np.ndarray, d: int) -> np.ndarray:
    """
    h_d(v) = E[ prod_{i=1..d} HW(z_i) | sum_i z_i = v mod q ].

    The shares (z_1..z_{d-1}) are uniform and independent, so this is the
    d-fold cyclic autoconvolution of HW divided by q^(d-1).
    """
    q = len(hw)
    if d == 1:
        return hw.copy()
    f = np.fft.rfft(hw)
    conv = np.fft.irfft(f ** d, n=q)
    return conv / (q ** (d - 1))


# --------------------------------------------------------------------------
# Trace simulation
# --------------------------------------------------------------------------

@dataclass
class Scenario:
    name: str
    shares: int          # d = 1 means unprotected
    shuffle: bool


SCENARIOS = [
    Scenario("NONE",        shares=1, shuffle=False),
    Scenario("MASK_d2",     shares=2, shuffle=False),
    Scenario("MASK_d3",     shares=3, shuffle=False),
    Scenario("SHUFFLE",     shares=1, shuffle=True),
    Scenario("MASK2_SHUF",  shares=2, shuffle=True),
]


def simulate_traces(ntt: NegacyclicNTT,
                    shat: np.ndarray,
                    n_traces: int,
                    scenario: Scenario,
                    sigma: float,
                    rng: np.random.Generator,
                    fixed_c1: np.ndarray | None = None):
    """
    Returns
    -------
    traces : (n_traces, N, d) float32   leakage of every share of every slot
    chat1  : (n_traces, N)   int64      public NTT-domain ciphertext component
    slot   : (n_traces, N)   int64      slot[r, k] = time slot holding coeff k
    """
    n, q, d = ntt.n, ntt.q, scenario.shares

    if fixed_c1 is None:
        c1 = rng.integers(0, q, size=(n_traces, n), dtype=np.int64)
    else:
        c1 = np.broadcast_to(fixed_c1, (n_traces, n)).copy()
    chat1 = ntt.forward(c1)

    # ---- arithmetic mask shares of shat, refreshed for every execution
    if d == 1:
        shares = shat[None, :, None] * np.ones((n_traces, 1, 1), dtype=np.int64)
    else:
        rnd = rng.integers(0, q, size=(n_traces, n, d - 1), dtype=np.int64)
        last = (shat[None, :] - rnd.sum(axis=2)) % q
        shares = np.concatenate([rnd, last[:, :, None]], axis=2)

    # ---- the actual sensitive intermediates z_i = chat1 * shat_i mod q
    z = (chat1[:, :, None] * shares) % q

    hw = hamming_weight_table(q)
    leak = hw[z] + rng.normal(0.0, sigma, size=z.shape)

    # ---- shuffling: coefficient k is executed in slot perm[r, k]
    if scenario.shuffle:
        perm = np.argsort(rng.random((n_traces, n)), axis=1)   # slot -> coeff
        traces = np.take_along_axis(leak, perm[:, :, None], axis=1)
        slot = np.argsort(perm, axis=1)                        # coeff -> slot
    else:
        traces = leak
        slot = np.broadcast_to(np.arange(n), (n_traces, n)).copy()

    return traces.astype(np.float32), chat1, slot


def combine(traces: np.ndarray, d: int) -> np.ndarray:
    """
    Centred-product combining of the d share sub-samples of each slot.
    d = 1 reduces to the raw first-order sample.
    Returns (n_traces, N) float32.
    """
    centred = traces - traces.mean(axis=0, keepdims=True)
    return np.prod(centred, axis=2).astype(np.float32)


# --------------------------------------------------------------------------
# CPA
# --------------------------------------------------------------------------

def cpa(combined: np.ndarray,
        chat1: np.ndarray,
        target_k: int,
        predictor: np.ndarray,
        q: int,
        true_shat_k: int,
        hyp_block: int = 256):
    """
    Correlate every key hypothesis g in Z_q against every time slot.

    Returns (rho_correct, rho_best, rank_of_correct, guessed_key).
    """
    n_traces, n_slots = combined.shape

    T = combined - combined.mean(axis=0, keepdims=True)
    T /= (T.std(axis=0, keepdims=True) + 1e-12)
    T = T.astype(np.float32)

    c = chat1[:, target_k].astype(np.int64)
    best_per_hyp = np.empty(q, dtype=np.float32)

    for lo in range(0, q, hyp_block):
        hi = min(lo + hyp_block, q)
        g = np.arange(lo, hi, dtype=np.int64)
        v = (c[:, None] * g[None, :]) % q            # (n_traces, block)
        H = predictor[v].astype(np.float32)
        H -= H.mean(axis=0, keepdims=True)
        H /= (H.std(axis=0, keepdims=True) + 1e-12)
        # (block, n_slots)
        r = np.abs(H.T @ T) / n_traces
        best_per_hyp[lo:hi] = r.max(axis=1)

    guess = int(np.argmax(best_per_hyp))
    rho_correct = float(best_per_hyp[true_shat_k])
    rho_best = float(best_per_hyp[guess])
    rank = int((best_per_hyp > best_per_hyp[true_shat_k]).sum())
    return rho_correct, rho_best, rank, guess


# --------------------------------------------------------------------------
# TVLA
# --------------------------------------------------------------------------

def welch_t(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """
    Welch t per sample, with a guard for constant samples.

    An earlier version added 1e-30 to the denominator. That is not a guard:
    when a sample is constant in both groups the denominator becomes 1e-30 and
    the statistic explodes, producing |t| in the hundreds at samples that
    cannot carry any secret. A 20-seed run made this visible (one seed in
    twenty returned |t| = 263 for a masked build whose other nineteen seeds
    all sat between 2.45 and 3.42). Constant samples are now excluded.
    """
    ma, mb = a.mean(axis=0), b.mean(axis=0)
    va, vb = a.var(axis=0, ddof=1), b.var(axis=0, ddof=1)
    den = np.sqrt(va / len(a) + vb / len(b))
    scale = max(1.0, float(np.abs(a).max()) if a.size else 1.0)
    degenerate = den < 1e-9 * scale
    out = np.zeros_like(den)
    ok = ~degenerate
    out[ok] = (ma[ok] - mb[ok]) / den[ok]
    return out


# NOTE: the partition is fixed-INPUT vs random-INPUT with the secret held
# fixed, which is the standard TVLA setup. An attempt to partition on the
# secret instead was tried and reverted: for this target the intermediate
# c1*s is uniform for any non-zero s when c1 is uniform, so a secret-based
# partition detects nothing -- it took the unprotected build from |t| ~ 200
# down to a median of 2.7. The ELMO harness is different and does partition
# on the secret, because its leakage model covers far more intermediates.
def tvla(ntt, shat, n_traces, scenario, sigma, rng):
    """Non-specific fixed-vs-random t-test, first order and order d."""
    q = ntt.q
    # The TVLA fixed input must not be degenerate. If NTT(c1) has a zero at
    # coefficient k then z_k = chat1_k * s_k = 0 on every trace of the fixed
    # group, that column carries no leakage at all, and the resulting Welch
    # statistic is enormous while meaning nothing about the countermeasure.
    # The probability is 1-(1-1/q)^N, which is 3.8% at q=3329, N=128 -- rare
    # enough to be invisible at 5 seeds and to appear once in 20. Resample.
    for _attempt in range(100):
        fixed_c1 = rng.integers(0, q, size=ntt.n, dtype=np.int64)
        if not (ntt.forward(fixed_c1[None, :])[0] == 0).any():
            break
    else:
        raise RuntimeError("could not draw a non-degenerate fixed input")
    half = n_traces // 2
    tf, _, _ = simulate_traces(ntt, shat, half, scenario, sigma, rng, fixed_c1=fixed_c1)
    tr, _, _ = simulate_traces(ntt, shat, half, scenario, sigma, rng, fixed_c1=None)

    t1 = welch_t(tf.reshape(half, -1), tr.reshape(half, -1))
    if scenario.shares == 1:
        return float(np.abs(t1).max()), float("nan")
    td = welch_t(combine(tf, scenario.shares), combine(tr, scenario.shares))
    return float(np.abs(t1).max()), float(np.abs(td).max())


# --------------------------------------------------------------------------
# BFV correctness / blinding
# --------------------------------------------------------------------------

def bfv_correctness(n_users: int, trials: int, rng: np.random.Generator, mode: str):
    """
    mode = 'none'       : plain additive aggregation
           'paper'      : c' = c + Enc(r), r ~ N(0, sigma_b) sampled in the
                          *plaintext* slot  -- the construction written in
                          Section 3.5 of the manuscript
           'rerandomise': c' = c + Enc(0) with fresh randomness  -- the
                          construction that actually preserves correctness
    Returns (exact_matches, trials, max_abs_error).
    """
    n, q, t, sig = CORR_N, CORR_Q, CORR_T, CORR_SIGMA
    delta = q // t
    ok, max_err = 0, 0
    _ntt = NegacyclicNTT(n, q)

    def mul(x, y):
        return _ntt.inverse((_ntt.forward(x % q) * _ntt.forward(y % q)) % q)

    for _ in range(trials):
        s = rng.integers(-1, 2, size=n, dtype=np.int64)
        a = rng.integers(0, q, size=n, dtype=np.int64)
        e = np.round(rng.normal(0, sig, size=n)).astype(np.int64)
        b = (-(mul(a, s)) + e) % q          # pk = (b, a)

        c0 = np.zeros(n, dtype=np.int64)
        c1 = np.zeros(n, dtype=np.int64)
        true_sum = 0

        for _u in range(n_users):
            m = int(rng.integers(1, 6))
            true_sum += m
            u = rng.integers(-1, 2, size=n, dtype=np.int64)
            e1 = np.round(rng.normal(0, sig, size=n)).astype(np.int64)
            e2 = np.round(rng.normal(0, sig, size=n)).astype(np.int64)
            mm = np.zeros(n, dtype=np.int64)
            mm[0] = m
            d0 = (mul(b, u) + e1 + delta * mm) % q
            d1 = (mul(a, u) + e2) % q

            if mode == "paper":
                r = int(round(rng.normal(0, 3.0)))
                rr = np.zeros(n, dtype=np.int64)
                rr[0] = r
                v = rng.integers(-1, 2, size=n, dtype=np.int64)
                f1 = np.round(rng.normal(0, sig, size=n)).astype(np.int64)
                f2 = np.round(rng.normal(0, sig, size=n)).astype(np.int64)
                d0 = (d0 + mul(b, v) + f1 + delta * rr) % q
                d1 = (d1 + mul(a, v) + f2) % q
            elif mode == "rerandomise":
                v = rng.integers(-1, 2, size=n, dtype=np.int64)
                f1 = np.round(rng.normal(0, sig, size=n)).astype(np.int64)
                f2 = np.round(rng.normal(0, sig, size=n)).astype(np.int64)
                d0 = (d0 + mul(b, v) + f1) % q
                d1 = (d1 + mul(a, v) + f2) % q

            c0 = (c0 + d0) % q
            c1 = (c1 + d1) % q

        raw = (c0 + mul(c1, s)) % q
        rec = int(np.round(raw[0] * t / q)) % t
        err = abs(rec - true_sum % t)
        max_err = max(max_err, err)
        ok += int(err == 0)

    return ok, trials, max_err


# --------------------------------------------------------------------------
# Experiment driver
# --------------------------------------------------------------------------

def run(args):
    t0 = time.time()
    ntt = NegacyclicNTT(args.poly_n, args.q)
    hw = hamming_weight_table(args.q)
    predictors = {d: order_d_predictor(hw, d) for d in (1, 2, 3)}

    rows = []
    for seed in range(getattr(args, 'seed_offset', 0),
                      getattr(args, 'seed_offset', 0) + args.seeds):
        rng = np.random.default_rng(1000 + seed)
        s = rng.integers(-1, 2, size=ntt.n, dtype=np.int64)
        shat = ntt.forward(s % args.q)
        target_k = 0

        for sc in SCENARIOS:
            for n_tr in args.traces:
                tr, chat1, _ = simulate_traces(ntt, shat, n_tr, sc, args.sigma, rng)

                res = {}
                for order in (1, sc.shares):
                    if order > 3:
                        continue
                    comb = combine(tr[:, :, :order], order)
                    rc, rb, rank, guess = cpa(comb, chat1, target_k,
                                              predictors[order], args.q,
                                              int(shat[target_k]))
                    res[order] = (rc, rb, rank, guess)

                t1, td = tvla(ntt, shat, n_tr, sc, args.sigma, rng)

                for order, (rc, rb, rank, guess) in res.items():
                    rows.append(dict(
                        seed=seed, scenario=sc.name, shares=sc.shares,
                        shuffle=sc.shuffle, n_traces=n_tr, attack_order=order,
                        rho_correct=rc, rho_best=rb, key_rank=rank,
                        recovered=int(guess == int(shat[target_k])),
                        tvla_1st=t1, tvla_dth=td,
                    ))
                print(f"  seed={seed} {sc.name:12s} n={n_tr:6d} "
                      f"rho1={res[1][0]:.4f} rank1={res[1][2]:5d} "
                      + (f"rho{sc.shares}={res[sc.shares][0]:.4f} "
                         f"rank{sc.shares}={res[sc.shares][2]:5d} "
                         if sc.shares > 1 else "")
                      + f"|t|1st={t1:6.2f} |t|dth={td:6.2f}",
                      flush=True)

    df = pd.DataFrame(rows)
    df.to_csv(args.out_csv, index=False)

    summary = (df.groupby(["scenario", "n_traces", "attack_order"])
                 .agg(rho_mean=("rho_correct", "mean"),
                      rho_std=("rho_correct", "std"),
                      rank_median=("key_rank", "median"),
                      success_rate=("recovered", "mean"),
                      tvla1_mean=("tvla_1st", "mean"),
                      tvlad_mean=("tvla_dth", "mean"))
                 .reset_index())
    summary.to_csv(args.out_csv.replace(".csv", "_summary.csv"), index=False)

    print("\n=== SUMMARY ===")
    print(summary.to_string(index=False))

    if args.correctness:
        print("\n=== BFV AGGREGATION CORRECTNESS ===")
        rng = np.random.default_rng(7)
        for mode in ("none", "rerandomise", "paper"):
            ok, tot, err = bfv_correctness(args.users, args.corr_trials, rng, mode)
            print(f"  {mode:12s}: {ok}/{tot} exact   max|error| = {err}")

    print(f"\nelapsed {time.time() - t0:.1f}s -> {args.out_csv}")
    return df, summary


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--poly-n", type=int, default=LEAK_N)
    p.add_argument("--q", type=int, default=LEAK_Q)
    p.add_argument("--sigma", type=float, default=1.0, help="leakage noise std")
    p.add_argument("--seeds", type=int, default=5)
    p.add_argument("--seed-offset", type=int, default=0,
                   help="run seeds [offset, offset+seeds); lets a 20-seed campaign be split into memory-safe batches")
    p.add_argument("--traces", type=int, nargs="+",
                   default=[500, 2000, 8000, 20000])
    p.add_argument("--out-csv", default="sca_results.csv")
    p.add_argument("--correctness", action="store_true")
    p.add_argument("--users", type=int, default=100)
    p.add_argument("--corr-trials", type=int, default=20)
    p.add_argument("--self-test", action="store_true")
    args = p.parse_args()

    if args.self_test:
        self_test(args)
        return
    run(args)


def self_test(args):
    """Verify the NTT and the predictor before trusting any leakage result."""
    print("NTT round-trip and convolution check ...")
    ntt = NegacyclicNTT(args.poly_n, args.q)
    rng = np.random.default_rng(0)
    a = rng.integers(0, args.q, size=ntt.n, dtype=np.int64)
    b = rng.integers(0, args.q, size=ntt.n, dtype=np.int64)
    assert np.array_equal(ntt.inverse(ntt.forward(a)), a), "NTT round-trip failed"
    fast = ntt.inverse((ntt.forward(a) * ntt.forward(b)) % args.q)
    slow = schoolbook_negacyclic(a, b, args.q)
    assert np.array_equal(fast, slow), "NTT convolution != schoolbook"
    print("  NTT ok")

    print("predictor check (empirical vs analytic, d=2) ...")
    hw = hamming_weight_table(args.q)
    pred = order_d_predictor(hw, 2)
    q = args.q
    emp = np.zeros(8)
    for i, v in enumerate(rng.integers(0, q, size=8)):
        z1 = rng.integers(0, q, size=200000)
        z2 = (v - z1) % q
        emp[i] = (hw[z1] * hw[z2]).mean()
        print(f"  v={v:5d}  analytic={pred[v]:9.3f}  empirical={emp[i]:9.3f}")
    print("  predictor ok")

    print("BFV correctness check ...")
    r = np.random.default_rng(1)
    for mode in ("none", "rerandomise", "paper"):
        ok, tot, err = bfv_correctness(20, 5, r, mode)
        print(f"  {mode:12s}: {ok}/{tot} exact, max|error|={err}")


if __name__ == "__main__":
    main()
