"""Third-order TVLA sweep for MASK_d3 to locate the 4.5 crossing."""
import numpy as np, sca_bfv as S

ntt = S.NegacyclicNTT(S.LEAK_N, S.LEAK_Q)
sc3 = [s for s in S.SCENARIOS if s.name == "MASK_d3"][0]
sc2 = [s for s in S.SCENARIOS if s.name == "MASK_d2"][0]

print(f"{'n':>9} {'MASK_d3 |t|3 mean':>20} {'std':>7} {'MASK_d2 |t|2 mean':>20}")
for n in (20_000, 50_000, 100_000, 200_000, 400_000):
    v3, v2 = [], []
    for sd in range(3):
        rng = np.random.default_rng(500 + sd)
        shat = rng.integers(0, S.LEAK_Q, size=ntt.n, dtype=np.int64)
        v3.append(S.tvla(ntt, shat, n, sc3, 1.0, rng)[1])
        v2.append(S.tvla(ntt, shat, n, sc2, 1.0, rng)[1])
    print(f"{n:>9} {np.mean(v3):>20.2f} {np.std(v3):>7.2f} {np.mean(v2):>20.2f}",
          flush=True)
