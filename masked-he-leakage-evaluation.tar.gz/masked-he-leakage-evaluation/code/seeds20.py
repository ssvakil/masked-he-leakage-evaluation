"""20-seed run of the headline result (order mismatch, d=2), one seed at a
time so peak memory stays bounded. Reports mean, sd and a t-based 95% CI."""
import numpy as np, pandas as pd, gc, sca_bfv as S
from scipy import stats

ntt = S.NegacyclicNTT(S.LEAK_N, S.LEAK_Q)
sc2 = [x for x in S.SCENARIOS if x.name == "MASK_d2"][0]
sc1 = [x for x in S.SCENARIOS if x.name == "NONE"][0]
rows = []
for sd in range(20):
    for sc, name in ((sc1, "NONE"), (sc2, "MASK_d2")):
        rng = np.random.default_rng(7000 + sd)
        shat = rng.integers(0, S.LEAK_Q, size=ntt.n, dtype=np.int64)
        t1, td = S.tvla(ntt, shat, 20000, sc, 1.0, rng)[:2]
        rows.append(dict(seed=sd, scenario=name, t1=float(t1),
                         td=float(td) if td == td else np.nan))
        del rng, shat; gc.collect()
    print(f"seed {sd:>2} done", flush=True)
df = pd.DataFrame(rows); df.to_csv("seeds20.csv", index=False)
print()
for name in ("NONE", "MASK_d2"):
    for col, lab in (("t1", "order 1"), ("td", "order d")):
        v = df[df.scenario == name][col].dropna().values
        if len(v) < 2: continue
        m, sd_ = v.mean(), v.std(ddof=1)
        ci = stats.t.ppf(0.975, len(v)-1) * sd_ / np.sqrt(len(v))
        print(f"{name:<9} {lab:<8} n={len(v):>2}  mean={m:8.2f}  sd={sd_:6.2f}"
              f"  95% CI = [{m-ci:.2f}, {m+ci:.2f}]")
