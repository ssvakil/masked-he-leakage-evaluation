#!/usr/bin/env python3
"""
campaign.py -- expanded experimental campaign built on sca_bfv.py.

Adds, relative to the first run:
  E1  order-matched TVLA for masking orders d = 1..4, batched so that the
      trace budget can reach 10^6 without exhausting memory.
  E2  traces-to-detection (TTD) obtained by fitting |t| = c*sqrt(n) and
      solving for the 4.5 threshold, with a bootstrap confidence interval.
  E3  measurement-noise sweep sigma in {0.5, 1, 2, 4}.
  E4  validation of the CPA noise floor  rho ~ sqrt(2 ln|H|)/sqrt(n)
      against measured peak correlations of *failed* attacks.
  E5  shuffling-window sweep: window W in {1, 8, 32, 128}.

All output goes to campaign_*.csv.
"""
from __future__ import annotations

import itertools
import json

import numpy as np
import pandas as pd

import sca_bfv as S

NTT = S.NegacyclicNTT(S.LEAK_N, S.LEAK_Q)
Q = S.LEAK_Q
N = S.LEAK_N
THRESHOLD = 4.5
BATCH = 20_000


# ---------------------------------------------------------------------------
# Batched order-d fixed-vs-random TVLA
# ---------------------------------------------------------------------------
def _group_stats(shat, n, scenario, sigma, seed, fixed_c1):
    """Two-pass batched mean/var of the order-d combined statistic."""
    d = scenario.shares

    # pass 1: per-(slot, share) means, needed for centring
    tot = np.zeros((N, d), dtype=np.float64)
    cnt = 0
    rng = np.random.default_rng(seed)
    for start in range(0, n, BATCH):
        b = min(BATCH, n - start)
        tr, _, _ = S.simulate_traces(NTT, shat, b, scenario, sigma, rng,
                                     fixed_c1=fixed_c1)
        tot += tr.sum(axis=0, dtype=np.float64)
        cnt += b
    mean_share = tot / cnt

    # pass 2: combined statistic, accumulate mean and variance
    s1 = np.zeros(N, dtype=np.float64)
    s2 = np.zeros(N, dtype=np.float64)
    rng = np.random.default_rng(seed)          # identical stream
    for start in range(0, n, BATCH):
        b = min(BATCH, n - start)
        tr, _, _ = S.simulate_traces(NTT, shat, b, scenario, sigma, rng,
                                     fixed_c1=fixed_c1)
        centred = tr - mean_share[None, :, :]
        comb = np.prod(centred, axis=2, dtype=np.float64)
        s1 += comb.sum(axis=0)
        s2 += (comb ** 2).sum(axis=0)
    m = s1 / cnt
    v = s2 / cnt - m ** 2
    return m, v * cnt / (cnt - 1), cnt


def tvla_batched(shat, n, scenario, sigma, seed):
    rng = np.random.default_rng(seed ^ 0xABCD)
    fixed_c1 = rng.integers(0, Q, size=N, dtype=np.int64)
    half = n // 2
    mf, vf, nf = _group_stats(shat, half, scenario, sigma, seed, fixed_c1)
    mr, vr, nr = _group_stats(shat, half, scenario, sigma, seed + 1, None)
    den = np.sqrt(vf / nf + vr / nr)
    den[den <= 0] = 1e-30
    return float(np.abs((mf - mr) / den).max())


# ---------------------------------------------------------------------------
# E1 + E3: TVLA vs n, for masking order d and noise sigma
# ---------------------------------------------------------------------------
def exp_tvla(orders, sigmas, ns, seeds):
    rows = []
    for d, sigma in itertools.product(orders, sigmas):
        sc = S.Scenario(f"MASK_d{d}", shares=d, shuffle=False)
        for n in ns:
            for sd in range(seeds):
                rng = np.random.default_rng(9000 + 31 * sd + d)
                shat = rng.integers(0, Q, size=N, dtype=np.int64)
                t = tvla_batched(shat, n, sc, sigma, 4000 + 17 * sd + d)
                rows.append(dict(experiment="tvla", d=d, sigma=sigma,
                                 n=n, seed=sd, max_t=t))
                print(f"  d={d} sigma={sigma} n={n:>8} seed={sd} |t|={t:8.2f}",
                      flush=True)
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# E2: traces to detection from a sqrt(n) fit
# ---------------------------------------------------------------------------
def fit_ttd(df, d, sigma, boot=2000):
    """|t| = c*sqrt(n)  ->  TTD = (4.5/c)^2, with bootstrap CI over seeds."""
    sub = df[(df.d == d) & (df.sigma == sigma)]
    x = np.sqrt(sub.n.values.astype(float))
    y = sub.max_t.values.astype(float)
    c = float((x * y).sum() / (x * x).sum())          # least squares, no intercept
    ttd = (THRESHOLD / c) ** 2

    rs = np.random.default_rng(0)
    idx = np.arange(len(x))
    boots = []
    for _ in range(boot):
        s = rs.choice(idx, size=len(idx), replace=True)
        cb = (x[s] * y[s]).sum() / (x[s] * x[s]).sum()
        boots.append((THRESHOLD / cb) ** 2)
    lo, hi = np.percentile(boots, [2.5, 97.5])

    resid = y - c * x
    ss_res = float((resid ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum())
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else float("nan")
    return dict(d=d, sigma=sigma, c=c, ttd=ttd, ttd_lo=lo, ttd_hi=hi, r2=r2)


# ---------------------------------------------------------------------------
# E4: CPA noise-floor validation
# ---------------------------------------------------------------------------
def exp_noise_floor(ns, seeds, sigma=1.0):
    """
    Peak |rho| of a *failed* first-order attack against a d=3 masked target,
    compared with the analytic order-statistic prediction.
    """
    sc = S.Scenario("MASK_d3", shares=3, shuffle=False)
    pred = np.sqrt(2 * np.log(Q))
    rows = []
    for n in ns:
        for sd in range(seeds):
            rng = np.random.default_rng(200 + sd)
            shat = rng.integers(0, Q, size=N, dtype=np.int64)
            tr, chat1, _ = S.simulate_traces(NTT, shat, n, sc, sigma, rng)
            comb = S.combine(tr, 1 if tr.shape[2] == 1 else tr.shape[2])
            # first-order attack on share 0 only: guaranteed to fail
            first = tr[:, :, 0]
            k = 0
            hw = S.hamming_weight_table(Q)
            guesses = np.arange(Q, dtype=np.int64)
            model = hw[(chat1[:, k][:, None] * guesses[None, :]) % Q]
            tc = first[:, k] - first[:, k].mean()
            mc = model - model.mean(axis=0, keepdims=True)
            num = tc @ mc
            den = np.linalg.norm(tc) * np.linalg.norm(mc, axis=0)
            den[den == 0] = 1e-30
            rho = float(np.abs(num / den).max())
            rows.append(dict(experiment="floor", n=n, seed=sd,
                             rho_measured=rho, rho_predicted=pred / np.sqrt(n)))
            print(f"  floor n={n:>7} seed={sd} measured={rho:.4f} "
                  f"predicted={pred/np.sqrt(n):.4f}", flush=True)
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# E5: shuffling window sweep
# ---------------------------------------------------------------------------
def exp_shuffle_window(windows, ns, seeds, sigma=1.0):
    """
    Restrict shuffling to a window of W slots. W=1 is no shuffling.
    Attacker performs first-order CPA on the *integrated* window, which is the
    correct stronger adversary.
    """
    hw = S.hamming_weight_table(Q)
    guesses = np.arange(Q, dtype=np.int64)
    rows = []
    for W in windows:
        for n in ns:
            for sd in range(seeds):
                rng = np.random.default_rng(700 + sd)
                shat = rng.integers(0, Q, size=N, dtype=np.int64)
                sc = S.Scenario("SH", shares=1, shuffle=False)
                tr, chat1, _ = S.simulate_traces(NTT, shat, n, sc, sigma, rng)
                leak = tr[:, :, 0]                       # (n, N)
                k = 0
                if W > 1:
                    slots = rng.integers(0, W, size=n)
                    obs = np.zeros((n, W), dtype=np.float64)
                    obs += rng.normal(0, sigma, size=(n, W))
                    obs[np.arange(n), slots] += leak[:, k]
                    integrated = obs.sum(axis=1)         # windowed adversary
                else:
                    integrated = leak[:, k].astype(np.float64)

                model = hw[(chat1[:, k][:, None] * guesses[None, :]) % Q]
                tc = integrated - integrated.mean()
                mc = model - model.mean(axis=0, keepdims=True)
                den = np.linalg.norm(tc) * np.linalg.norm(mc, axis=0)
                den[den == 0] = 1e-30
                corr = np.abs((tc @ mc) / den)
                rank = int((corr > corr[shat[k]]).sum())
                rows.append(dict(experiment="window", W=W, n=n, seed=sd,
                                 rho=float(corr.max()), rank=rank,
                                 success=int(rank == 0)))
                print(f"  W={W:>4} n={n:>7} seed={sd} rho={corr.max():.4f} "
                      f"rank={rank}", flush=True)
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
def main():
    print("=== E1/E3: order-matched TVLA, d=1..4, sigma sweep ===", flush=True)
    ns = [2_000, 8_000, 20_000, 50_000, 100_000, 200_000]
    tv = exp_tvla(orders=[1, 2, 3, 4], sigmas=[1.0], ns=ns, seeds=3)
    tv_sig = exp_tvla(orders=[2, 3], sigmas=[0.5, 2.0, 4.0],
                      ns=[8_000, 50_000, 200_000], seeds=3)
    tvla_all = pd.concat([tv, tv_sig], ignore_index=True)
    tvla_all.to_csv("campaign_tvla.csv", index=False)

    print("\n=== E2: traces to detection ===", flush=True)
    fits = []
    for d in sorted(tvla_all.d.unique()):
        for sg in sorted(tvla_all[tvla_all.d == d].sigma.unique()):
            f = fit_ttd(tvla_all, d, sg)
            fits.append(f)
            print(f"  d={d} sigma={sg}: TTD={f['ttd']:.3g} "
                  f"[{f['ttd_lo']:.3g}, {f['ttd_hi']:.3g}]  R2={f['r2']:.4f}",
                  flush=True)
    pd.DataFrame(fits).to_csv("campaign_ttd.csv", index=False)

    print("\n=== E4: CPA noise floor ===", flush=True)
    fl = exp_noise_floor([2_000, 8_000, 20_000, 50_000, 100_000], seeds=3)
    fl.to_csv("campaign_floor.csv", index=False)

    print("\n=== E5: shuffling window ===", flush=True)
    wn = exp_shuffle_window([1, 8, 32, 128], [2_000, 8_000, 20_000, 50_000],
                            seeds=3)
    wn.to_csv("campaign_window.csv", index=False)

    print("\nDone. Wrote campaign_tvla.csv, campaign_ttd.csv, "
          "campaign_floor.csv, campaign_window.csv")


if __name__ == "__main__":
    main()
