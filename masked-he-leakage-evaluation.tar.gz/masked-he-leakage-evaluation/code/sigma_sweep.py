import numpy as np, pandas as pd, sca_bfv as S
ntt=S.NegacyclicNTT(S.LEAK_N,S.LEAK_Q)
rows=[]
for d in (2,3):
    sc=S.Scenario(f"d{d}",shares=d,shuffle=False)
    for sigma in (1.0,2.0,4.0,8.0):
        for n in (8000,20000,50000):
            vals=[]
            for sd in range(3):
                rng=np.random.default_rng(3000+sd)
                shat=rng.integers(0,S.LEAK_Q,size=ntt.n,dtype=np.int64)
                vals.append(S.tvla(ntt,shat,n,sc,sigma,rng)[1])
            rows.append(dict(d=d,sigma=sigma,n=n,
                             t_mean=float(np.mean(vals)),t_std=float(np.std(vals))))
            print(f"d={d} sigma={sigma:>4} n={n:>6} |t|={np.mean(vals):7.2f} +/-{np.std(vals):5.2f}",flush=True)
pd.DataFrame(rows).to_csv("campaign_sigma.csv",index=False)
