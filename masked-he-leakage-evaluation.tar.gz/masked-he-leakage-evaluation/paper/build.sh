#!/bin/bash
# LaTeX needs four passes: the first writes .aux, bibtex reads it, and two
# more passes resolve citations and cross-references. Running pdflatex once
# and reading the "undefined" warnings is the usual false alarm.
set -e
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode main.tex > /dev/null
bibtex main > /dev/null
pdflatex -interaction=nonstopmode main.tex > /dev/null
pdflatex -interaction=nonstopmode main.tex > build.log 2>&1
echo "errors:    $(grep -cE '^! ' build.log)"
echo "undefined: $(grep -c 'undefined' build.log)"
echo "pages:     $(pdfinfo main.pdf 2>/dev/null | awk '/Pages/{print $2}')"
