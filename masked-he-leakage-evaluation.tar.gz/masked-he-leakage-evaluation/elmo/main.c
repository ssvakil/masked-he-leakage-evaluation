/*
 * Masked BFV/Kyber-style pointwise multiplication for ELMO.
 *
 * Target intermediate:  z_i = chat1 * shat_i  (mod q),  q = 3329
 * with shat = sum_i shat_i (mod q), shares refreshed every execution.
 *
 * Reduction is Montgomery, as in reference lattice implementations, so the
 * instruction sequence under the trigger is the one a real implementation
 * executes -- not a modulo operator lowered to a software division routine.
 *
 * Build NSHARES=1 (unprotected), 2 (first order), or 3 (second order).
 *
 * ELMO runs the fixed group first, then resetdatafile(), then the random
 * group, which is the layout its built-in fixed-vs-random TVLA expects.
 */
#include "main.h"

#define KYBER_Q    3329
#define QINV      (-3327)          /* q^-1 mod 2^16 */

#ifndef NSHARES
#define NSHARES 2
#endif
#ifndef NOTRACES
#define NOTRACES 400
#endif

/*
 * Barrier between share computations.
 *
 * Zeroing the carrier registers does NOT work: overwriting a register that
 * holds z_j with zero produces a bus transition of Hamming distance HW(z_j),
 * so it leaks each share directly.  Instead we run the SAME fqmul sequence on
 * fresh random operands.  The carriers then transition z0 -> random -> z1,
 * and each transition is independent of the secret.  Using the identical
 * instruction sequence also keeps the three-instruction model windows
 * unchanged, so no new leakage sources are introduced.
 */
static short barrett_reduce(short a)
{
    short t;
    const short v = ((1 << 26) + KYBER_Q / 2) / KYBER_Q;
    t  = (short)(((int)v * a + (1 << 25)) >> 26);
    t *= KYBER_Q;
    return (short)(a - t);
}

static short montgomery_reduce(int a)
{
    short t;
    t = (short)((short)a * QINV);
    t = (short)((a - (int)t * KYBER_Q) >> 16);
    return t;
}

static short fqmul(short a, short b)
{
    return montgomery_reduce((int)a * b);
}

int main(void)
{
    unsigned char b0, b1, r0, r1;
    short chat1, shares[NSHARES], acc[NSHARES];
    short rnd_a[NSHARES], rnd_b[NSHARES];
    short sum, secret, m;
    int t, j;

    const short fixedsecret = 1234;

    /*
     * GROUPMASK is -1 for the fixed group and 0 for the random group, set at
     * compile time.  The two builds are compiled from the SAME source with the
     * SAME control flow; only the value of a constant differs, and it is
     * consumed by a branchless mask select.  Both binaries therefore execute
     * an identical instruction sequence and produce traces of identical
     * length.  Verify that before interpreting any statistic.
     */
    {
        /* volatile read: prevents the compiler from folding the mask away and
           emitting different code for the two builds */
        static volatile short mv;
        mv = (short)(GROUPMASK);
        m  = mv;
    }

    for (t = 0; t < NOTRACES; t++) {
        readbyte(&b0);
        readbyte(&b1);
        chat1 = barrett_reduce((short)(((unsigned short)b1 << 8) | b0));

        randbyte(&r0);
        randbyte(&r1);
        secret = barrett_reduce((short)(((unsigned short)r1 << 8) | r0));
        secret = (short)((secret & (short)~m) | (fixedsecret & m));

        sum = 0;
        for (j = 0; j < NSHARES - 1; j++) {
            randbyte(&r0);
            randbyte(&r1);
            shares[j] = barrett_reduce((short)(((unsigned short)r1 << 8) | r0));
            sum = barrett_reduce((short)(sum + shares[j]));
        }
        shares[NSHARES - 1] = barrett_reduce((short)(secret - sum));

#ifdef WITH_BARRIER
        for (j = 0; j < NSHARES; j++) {
            randbyte(&r0); randbyte(&r1);
            rnd_a[j] = barrett_reduce((short)(((unsigned short)r1 << 8) | r0));
            randbyte(&r0); randbyte(&r1);
            rnd_b[j] = barrett_reduce((short)(((unsigned short)r1 << 8) | r0));
        }
#endif
        starttrigger();
        for (j = 0; j < NSHARES; j++) {
            acc[j] = fqmul(chat1, shares[j]);
#ifdef WITH_BARRIER
            acc[j] = (short)(acc[j] ^ fqmul(rnd_a[j], rnd_b[j]) ^ acc[j]);
#endif
        }
        endtrigger();

        for (j = 0; j < NSHARES; j++)
            printbyte((unsigned char *)&acc[j]);
    }

    endprogram();
    return 0;
}
