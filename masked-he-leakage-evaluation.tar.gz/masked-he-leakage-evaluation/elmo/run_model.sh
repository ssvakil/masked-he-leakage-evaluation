#!/bin/bash
set -e
BIN=$1; D=$2; NT=${3:-500}
cd Examples/MaskedBFV
for g in -1 0; do
  rm -f main.o main.elf main.bin main.map
  make NSHARES=$D NOTRACES=$NT GROUPMASK=$g EXTRA="" >/dev/null 2>&1
  n=$([ "$g" = "-1" ] && echo fixed || echo random)
  cp main.bin ../../b_$n.bin
done
cd ../..
for n in fixed random; do
  rm -rf output/traces; mkdir -p output/traces
  ./$BIN b_$n.bin >/dev/null 2>&1
  rm -rf /tmp/t_$n; mkdir -p /tmp/t_$n; cp output/traces/*.trc /tmp/t_$n/
done
