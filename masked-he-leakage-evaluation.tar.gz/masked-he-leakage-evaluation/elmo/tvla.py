"""
Order-matched fixed-vs-random TVLA on raw ELMO traces.

Refuses to report anything unless the two groups have identical trace-length
distributions, because unequal execution length between groups produces
enormous t-statistics that are misalignment, not leakage.

Order 1 : Welch t-test per cycle.
Order d : centred products over all d-subsets of cycles, Welch t-test on each.
          Constant cycles (zero variance) are excluded first, otherwise their
          degenerate denominators dominate the maximum.
"""
import numpy as np, glob, collections, sys, itertools

def load(d):
    return [np.loadtxt(f) for f in sorted(glob.glob(d + '/*.trc'))]

def main(order=1):
    F, R = load('/tmp/t_fixed'), load('/tmp/t_random')
    lf = collections.Counter(len(x) for x in F)
    lr = collections.Counter(len(x) for x in R)
    if len(lf) != 1 or lf != lr:
        print(f"  MISALIGNED fixed={dict(lf)} random={dict(lr)} -- refusing")
        sys.exit(1)
    F, R = np.array(F), np.array(R)
    nf, nr = len(F), len(R)

    keep = ~((F.var(0) < 1e-18) & (R.var(0) < 1e-18))
    Fk, Rk = F[:, keep], R[:, keep]
    ncyc = Fk.shape[1]
    print(f"  aligned at {F.shape[1]} cycles, {nf}+{nr} traces, "
          f"{int((~keep).sum())} constant cycles excluded")

    if order == 1:
        A, B = Fk, Rk
        label = "cycles"
    else:
        Fc = Fk - Fk.mean(0); Rc = Rk - Rk.mean(0)
        combos = list(itertools.combinations(range(ncyc), order))
        A = np.empty((nf, len(combos))); B = np.empty((nr, len(combos)))
        for k, c in enumerate(combos):
            A[:, k] = np.prod(Fc[:, c], axis=1)
            B[:, k] = np.prod(Rc[:, c], axis=1)
        label = f"{order}-tuples"

    ma, mb = A.mean(0), B.mean(0)
    va, vb = A.var(0, ddof=1), B.var(0, ddof=1)
    den = np.sqrt(va / nf + vb / nr)
    ok = den > 0
    t = np.zeros(A.shape[1]); t[ok] = (ma[ok] - mb[ok]) / den[ok]
    print(f"  order {order}: |t|>4.5 on {int((np.abs(t) > 4.5).sum())} "
          f"/ {A.shape[1]} {label}   max|t| = {np.abs(t).max():.2f}")
    return float(np.abs(t).max())

if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 1)

def expected_false_positives(n_tests, thr=4.5):
    from math import erfc, sqrt
    return n_tests * erfc(thr / sqrt(2))
