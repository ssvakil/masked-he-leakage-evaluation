# ELMO leakage-simulation project: masked BFV pointwise multiplication

Target intermediate: `z_i = chat1 * shat_i (mod q)`, q = 3329, Montgomery
reduction, as in reference lattice implementations. Build with `NSHARES=1`
(unprotected), `2` (first-order masking) or `3` (second-order masking).

## Why ELMO

The Hamming-weight simulation in `sca_bfv.py` uses a leakage model we wrote
ourselves. ELMO's models were built by regression against real ARM Cortex-M0
and M3 measurements (McCann, Oswald and Whitnall, USENIX Security 2017,
pp. 199-216), so the model is not ours and the evaluation is not circular.
This is the single change that most improves the credibility of the paper
without buying hardware.

## Build and run

```
git clone https://github.com/sca-research/ELMO.git
cd ELMO && make                       # builds the ./elmo binary
cp -r <this dir> Examples/MaskedBFV
cd Examples/MaskedBFV
cp ../FixedvsRandom/MaskedAES_R1/vector.o .
arm-none-eabi-gcc -mthumb -mcpu=cortex-m0 -msoft-float \
    -c ../elmoasmfunctions.s -o elmoasmfunctions.o
make NSHARES=2 NOTRACES=300
cd ../.. && ./elmo Examples/MaskedBFV/main.bin
```

Results land in `output/fixedvsrandomtstatistics.txt` and `output/traces/`.
`elmodefines.h` selects the power model: `coeffs.txt` is the Cortex-M0 model
from the USENIX paper, `coeffs_M3.txt` (the default) is the M3 model. State
which one you used.

## Harness note that matters

The fixed-versus-random partition is on the SECRET, with the public component
`chat1` random in both groups. An earlier version partitioned on `chat1`
instead. That makes the test detect leakage of a public value which masking is
not meant to hide, and the masked builds then appear to leak MORE than the
unprotected one. If your masked build looks worse than your unprotected one,
check this first.

## Results

Both groups are built from a single code path; only a constant differs, and it
is consumed through a volatile read and a branchless mask select, so the two
binaries execute an identical instruction sequence. `tvla.py` refuses to report
a statistic unless the two trace-length distributions are identical.

500 traces per group, cycle-accurate model, first-order fixed-vs-random on the
SECRET:

| build | aligned cycles | cycles with abs(t) > 4.5 | max abs(t) |
|-------|---------------|--------------------------|------------|
| NSHARES=1 (unprotected) | 57 | **3** | **23.18** |
| NSHARES=2 (first-order) | 49 | 0 | 2.93 |
| NSHARES=3 (second-order) | 76 | 0 | 2.22 |

The unprotected core leaks at first order, and both masked builds do not, at
this trace count and under this model. That is the expected behaviour.

To place the masked builds you still need (a) an order-matched test, using
`setmaskflowstart` / `initialisemaskflow` so ELMO's second-order test has masks
to analyse, and (b) a larger trace budget, so that traces-to-detection can be
estimated rather than only non-detection reported. Non-detection at 500 traces
is not security; see the paper's Section 4.

## Four harness faults found on the way here, all of which produced wrong answers

Each of these was caught by the data, not by reasoning about the code. Anyone
repeating this work should check for all four before believing a number.

1. **Partitioning on the public input.** The fixed-vs-random split was on
   `chat1` rather than on the secret. The test then detects leakage of a public
   value that masking is not meant to hide, and the masked builds appear to
   leak MORE than the unprotected one (26 and 62 leaky instructions against 33).

2. **Trusting the tool's leaky-instruction count.** ELMO's built-in test
   flagged `movs r2,#0`, `cmp r2,#4` and `adds r2,#2` -- loop counters that
   cannot carry secret data -- with statistics of order 1e14. These are
   zero-variance artefacts: the denominator of the t-statistic is ~0. Any
   analysis must guard against constant cycles.

3. **Unequal execution lengths between groups.** The fixed group ran 98 cycles
   and the random group 105, because the fixed group assigned a constant secret
   while the random group drew and reduced one. Comparing those sample-by-
   sample compares different instructions and yields max abs(t) = 2299, which
   is misalignment, not leakage. **Check the length distribution of both groups
   before computing anything.**

4. **Constant folding across the two builds.** With the group selector as a
   plain compile-time constant, gcc folded the mask select away and emitted
   different code for the two groups (820 vs 780 byte binaries). A volatile
   read fixes it; compare binary sizes as a cheap check.

Faults 1 and 3 each produced a confident, completely wrong conclusion --
namely that masking fails at first order on this core. It does not.

## Two fixes that were tried against the broken harness

Recorded because they are instructive, not because they were needed. Both were
evaluated while fault 3 was still present, so neither measurement means
anything about the countermeasure.

- Clearing r0-r3 between shares: no change. `r4`, the primary carrier, was not
  in the clobber list.
- Clearing r0-r6 between shares: much worse. Overwriting a register holding
  `z_j` with zero produces a bus transition of Hamming distance `HW(z_j)`, so
  zeroing leaks each share directly. Zeroing is not a barrier; it is a leakage
  source. This remains true independently of the harness fault.

## Register-level structure (for reference)

From `asmtrace_d2.txt` and `tstat_d2_nobarrier.txt`, taken under the broken
harness. `r3` and `r4` each carry share-0-dependent and then share-1-dependent
data across the two `fqmul` calls, and ELMO's model includes Hamming-distance
terms on the data bus over a three-instruction window. This is the mechanism by
which software masking can fail on a real core (Papagiannopoulos and
Veshchikov, COSADE 2017) and is worth watching for, but it is NOT what these
traces demonstrate, because the measurement they come from was invalid.

## Reproducing

```
./run_tvla.sh 1 500      # then: python3 tvla.py
./run_tvla.sh 2 500
./run_tvla.sh 3 500
```
